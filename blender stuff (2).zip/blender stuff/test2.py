import cv2
import numpy as np
from ultralytics import YOLO
import concurrent.futures
from multiprocessing import freeze_support

def zhang_suen_thinning(image):
    def get_neighbors(x, y, image):
        return [image[x-1][y], image[x-1][y+1], image[x][y+1], image[x+1][y+1],
                image[x+1][y], image[x+1][y-1], image[x][y-1], image[x-1][y-1]]

    def has_transition(neighbors):
        n = neighbors + neighbors[0:1]
        return sum((n1, n2) == (0, 1) for n1, n2 in zip(n, n[1:])) == 1

    def first_step(x, y, image):
        neighbors = get_neighbors(x, y, image)
        return (2 <= sum(neighbors) <= 6 and
                has_transition(neighbors) and
                neighbors[0] * neighbors[2] * neighbors[4] == 0 and
                neighbors[2] * neighbors[4] * neighbors[6] == 0)

    def second_step(x, y, image):
        neighbors = get_neighbors(x, y, image)
        return (2 <= sum(neighbors) <= 6 and
                has_transition(neighbors) and
                neighbors[0] * neighbors[2] * neighbors[6] == 0 and
                neighbors[0] * neighbors[4] * neighbors[6] == 0)

    image = image.copy()
    changing = True
    while changing:
        changing = False
        marked = []
        
        for x in range(1, image.shape[0]-1):
            for y in range(1, image.shape[1]-1):
                if image[x][y] == 1:
                    if first_step(x, y, image):
                        marked.append((x, y))
        
        for x, y in marked:
            image[x][y] = 0
            changing = True
        
        marked = []
        for x in range(1, image.shape[0]-1):
            for y in range(1, image.shape[1]-1):
                if image[x][y] == 1:
                    if second_step(x, y, image):
                        marked.append((x, y))
        
        for x, y in marked:
            image[x][y] = 0
            changing = True
            
    return image

def process_mask(mask, shape):
    mask = mask.astype(np.uint8)
    mask = cv2.resize(mask, shape)
    skeleton = zhang_suen_thinning(mask)
    contours, _ = cv2.findContours(skeleton, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    return contours

def main():
    img = cv2.imread('z.jpg')
    model = YOLO('my_wall_generator/weights/best2.pt')
    results = model.predict(img)
    result = results[0]
    
    if result.masks is not None:
        masks = result.masks.data.cpu().numpy()
        names = result.names
        
        futures = []
        with concurrent.futures.ProcessPoolExecutor() as executor:
            for i, mask in enumerate(masks):
                class_id = int(result.boxes.cls[i])
                if names[class_id].lower() == "wwaall":
                    futures.append(executor.submit(process_mask, mask, (img.shape[1], img.shape[0])))
                    
        centerline_contours = [f.result() for f in concurrent.futures.as_completed(futures)]
        for c in centerline_contours:
            print("Centerline contours:",len(c))
    cv2.destroyAllWindows()

if __name__ == '__main__':
    freeze_support()
    main()