bl_info = {
    "name": "Wall Generator",
    "author": "Your Name",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Wall Generator",
    "description": "Generate walls from floor plan images using AI",
    "category": "Object",
}

import bpy
import os
import sys
import subprocess
import numpy as np

import math
class WallGeneratorPanel(bpy.types.Panel):
    bl_label = "Wall Generator"
    bl_idname = "VIEW3D_PT_wall_generator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Wall Generator'

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "floor_plan_path")
        layout.prop(context.scene, "wall_height")
        layout.prop(context.scene, "angle_threshold")
        layout.prop(context.scene, "distance_threshold")
        layout.operator("object.generate_walls")

class WallGeneratorOperator(bpy.types.Operator):
    bl_idname = "object.generate_walls"
    bl_label = "Generate Walls"

    def create_floor(self, wall_verts):
        if not wall_verts:
            return

        min_x = min(v[0] for v in wall_verts)
        max_x = max(v[0] for v in wall_verts)
        min_y = min(v[1] for v in wall_verts)
        max_y = max(v[1] for v in wall_verts)

        verts = [
            (min_x, min_y, 0),
            (max_x, min_y, 0),
            (max_x, max_y, 0),
            (min_x, max_y, 0)
        ]

        faces = [(0, 1, 2, 3)]

        mesh = bpy.data.meshes.new('Floor')
        mesh.from_pydata(verts, [], faces)
        mesh.update()

        obj = bpy.data.objects.new('Floor', mesh)
        bpy.context.scene.collection.objects.link(obj)

        # Apply material
        material = bpy.data.materials.new(name="Floor_Material")
        material.use_nodes = True
        material.node_tree.nodes["Principled BSDF"].inputs[0].default_value = (0.5, 0.5, 0.5, 1)
        obj.data.materials.append(material)
    def load_window(self, bbox, wall_height):
        """Load and place window with dimensions matching bbox"""
        # Get window blend file
        addon_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        blend_path = os.path.join(addon_dir, "models", "window.blend")
        
        # Load window model
        with bpy.data.libraries.load(blend_path, link=False) as (data_from, data_to):
            data_to.objects = [name for name in data_from.objects if name.startswith("Window")]
        
        window_obj = data_to.objects[0]
        bpy.context.scene.collection.objects.link(window_obj)
        
        # Calculate bbox dimensions
        width = abs(bbox[2] - bbox[0])   # x2 - x1
        height = abs(bbox[3] - bbox[1])  # y2 - y1
        mid_x = (bbox[0] + bbox[2]) / 2
        mid_y = (bbox[1] + bbox[3]) / 2
        
        # Get original window dimensions
        original_width = window_obj.dimensions.x
        original_height = window_obj.dimensions.y
        
        # First set rotation based on dimensions
        if width > height:
            # Horizontal window
            window_obj.rotation_euler[2] = 0
            # Scale to match bbox
            scale_x = width / original_width
            scale_y = height / original_height
        else:
            # Vertical window
            window_obj.rotation_euler[2] = math.pi/2
            # Swap scales for vertical orientation
            scale_x = height / original_width  
            scale_y = width / original_height
        
        # Apply scale
        window_obj.scale = (scale_x, scale_y, wall_height/window_obj.dimensions.z)
        
        # Position window at midpoint
        window_obj.location = (mid_x, mid_y, wall_height/2)
        
        return window_obj

    def create_wall_material(self):
        mat_name = "WallMaterial"

        # Check if the material already exists
        material = bpy.data.materials.get(mat_name)
        if material is not None:
            return material

        # Create a new material
        material = bpy.data.materials.new(name=mat_name)
        material.use_nodes = True

        # Get the material's node tree
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        # Clear default nodes
        nodes.clear()

        # Add Material Output node
        output_node = nodes.new(type='ShaderNodeOutputMaterial')
        output_node.location = (400, 0)

        # Add Principled BSDF node
        principled_node = nodes.new(type='ShaderNodeBsdfPrincipled')
        principled_node.location = (0, 0)

        # Connect Principled BSDF to Material Output
        links.new(principled_node.outputs['BSDF'], output_node.inputs['Surface'])

        script_dir =  os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        # Paths to your texture images
        diffuse_texture_path = os.path.join(script_dir, 'textures', 'wall_diffuse.jpg')
        normal_map_path = os.path.join(script_dir, 'textures', 'wall_normal.exr')
        roughness_map_path = os.path.join(script_dir, 'textures', 'wall_rough.exr')
        displacement_map_path = os.path.join(script_dir, 'textures', 'wall_displacement.jpg')

        # Load and set up Diffuse (Base Color) texture
        if os.path.exists(diffuse_texture_path):
            diffuse_node = nodes.new(type='ShaderNodeTexImage')
            diffuse_node.image = bpy.data.images.load(diffuse_texture_path)
            diffuse_node.location = (-400, 200)
            links.new(diffuse_node.outputs['Color'], principled_node.inputs['Base Color'])

        # Load and set up Normal Map texture
        if os.path.exists(normal_map_path):
            normal_map_node = nodes.new(type='ShaderNodeTexImage')
            normal_map_node.image = bpy.data.images.load(normal_map_path)
            normal_map_node.location = (-400, 0)
            normal_map_node.image.colorspace_settings.is_data = True  # Set to Non-Color Data

            normal_map_converter = nodes.new(type='ShaderNodeNormalMap')
            normal_map_converter.location = (-200, 0)

            # Connect the normal map texture to the normal map converter
            links.new(normal_map_node.outputs['Color'], normal_map_converter.inputs['Color'])

            # Connect the normal map converter to the Principled BSDF
            links.new(normal_map_converter.outputs['Normal'], principled_node.inputs['Normal'])

        # Load and set up Roughness Map texture
        if os.path.exists(roughness_map_path):
            roughness_node = nodes.new(type='ShaderNodeTexImage')
            roughness_node.image = bpy.data.images.load(roughness_map_path)
            roughness_node.location = (-400, -200)
            roughness_node.image.colorspace_settings.is_data = True  # Set to Non-Color Data

            # Connect the roughness map to the Principled BSDF
            links.new(roughness_node.outputs['Color'], principled_node.inputs['Roughness'])

        # Load and set up Displacement Map texture
        if os.path.exists(displacement_map_path):
            displacement_node = nodes.new(type='ShaderNodeTexImage')
            displacement_node.image = bpy.data.images.load(displacement_map_path)
            displacement_node.location = (-400, -400)
            displacement_node.image.colorspace_settings.is_data = True  # Set to Non-Color Data

            # Create a Displacement node
            displacement_converter = nodes.new(type='ShaderNodeDisplacement')
            displacement_converter.location = (-200, -400)
            displacement_converter.inputs['Scale'].default_value = 0.1  # Adjust the scale as needed

            # Connect the displacement map texture to the displacement node
            links.new(displacement_node.outputs['Color'], displacement_converter.inputs['Height'])

            # Connect the displacement node to the Material Output
            links.new(displacement_converter.outputs['Displacement'], output_node.inputs['Displacement'])

        return material
    def create_wall_from_contour(self, coords, wall_height, index):
        # Coordinates are already scaled
        #simplified_coords = detect_wall_orientation(coords)
        simplified_coords = simplify_wall_contour(coords)
        # Create bottom vertices and edges
        verts = [(v[0], v[1], 0) for v in simplified_coords]
        edges = [(i, (i + 1) % len(simplified_coords)) for i in range(len(simplified_coords))]

        mesh = bpy.data.meshes.new(f'Wall_{index}')
        mesh.from_pydata(verts, edges, [])
        mesh.update()

        obj = bpy.data.objects.new(f'Wall_{index}', mesh)
        bpy.context.scene.collection.objects.link(obj)
        bpy.context.view_layer.objects.active = obj

        # Create wall
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.edge_face_add()
        bpy.ops.mesh.extrude_region_move(
            TRANSFORM_OT_translate={"value": (0, 0, wall_height)}
        )
        bpy.ops.object.mode_set(mode='OBJECT')

        # Apply material
        material = self.create_wall_material()
        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)

        return obj
    
    def execute(self, context):
        
        try:
            # Import dependencies
            from ultralytics import YOLO
            from shapely.geometry import Polygon
            import numpy as np
            
        except ImportError as e:
            self.report({'ERROR'}, f"Error importing dependencies: {e}")
            return {'CANCELLED'}

        # Remove existing walls
        for obj in bpy.data.objects:
            if obj.name.startswith('Wall_') or obj.name == 'Floor':
                bpy.data.objects.remove(obj, do_unlink=True)
        # Load model and process image
        addon_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        model_path = os.path.join(addon_dir, "weights", "best2.pt")
        model_path2 = os.path.join(addon_dir, "weights", "windows.pt")
        # Verify if weights file exists
        if not os.path.exists(model_path):
            self.report({'ERROR'}, f"Model weights not found at: {model_path}\nExpected path: {model_path}")
            return {'CANCELLED'}
        if not os.path.exists(model_path2):
            self.report({'ERROR'}, f"Model weights not found at: {model_path2}\nExpected path: {model_path2}")
            return {'CANCELLED'}

        model = YOLO(model_path)
        model2 = YOLO(model_path2)
        image_path = context.scene.floor_plan_path
        if not os.path.exists(image_path):
            self.report({'ERROR'}, f"Image not found: {image_path}")
            return {'CANCELLED'}

        results = model.predict(image_path, conf=0.6)[0]
        wall_height = context.scene.wall_height
        scaling_factor = 0.005  # Adjust as needed

        results_2=model2.predict(image_path, conf=0.6)
        windows_boxes=results_2[0].cpu().numpy().boxes
        windows_masks = results_2[0].masks
        windows_names = results_2[0].cpu().numpy().names
        # Use the threshold values from the scene
        angle_threshold = context.scene.angle_threshold
        distance_threshold = context.scene.distance_threshold

        # Process walls
        wall_verts = []
        for i in range(len(results.boxes)):
            class_name = results.names[int(results.boxes.cls[i])]
            if class_name in ['wwaall', 'wall']:
                coords = results.masks[i].xy[0]
                if isinstance(coords, np.ndarray):
                    coords = coords.tolist()

                # Scale coordinates here
                coords = snap_to_grid(coords)
                scaled_coords = [(x * scaling_factor, y * scaling_factor) for x, y in coords]
                simplified_coords = simplify_wall_contour(
                    scaled_coords, 
                    angle_threshold=angle_threshold,
                    distance_threshold=distance_threshold
                )
                wall_obj = self.create_wall_from_contour(simplified_coords, wall_height, i)
                wall_verts.extend([(v[0], v[1], 0) for v in scaled_coords])
        # Process windows and doors:
        for i in range(len(windows_boxes.cls)):
            self.report({'INFO'}, f"Door masks: {len(windows_masks.xy)}")
            # self.report({'INFO'}, f"Window detected: {results_2.names[int(results_2.boxes.cls[i])]}")
            self.report({'INFO'},f'Door box len: {len(windows_boxes.cls)}')
            class_name = windows_names[int(windows_boxes.cls[i])]
            win_coords = windows_masks[i].xy[0]
            scaled_win_coords=win_coords*scaling_factor
            bboxCorners = windows_boxes.xyxy[i].tolist()
            self.report({'INFO'}, f"Original bbox corners: {bboxCorners}")
            
            # Scale bbox corners
            scaled_bbox = [
                bboxCorners[0] * scaling_factor,  # x1
                bboxCorners[1] * scaling_factor,  # y1
                bboxCorners[2] * scaling_factor,  # x2
                bboxCorners[3] * scaling_factor   # y2
            ]
            if class_name == 'window':
                win_obj=self.load_window(scaled_bbox, wall_height)
                if window_obj:
                    self.report({'INFO'}, f"Window object location: {window_obj.location}")
            if class_name == 'door':
                # Get original bbox corners
                
                self.report({'INFO'}, f"Scaled bbox corners: {scaled_bbox}")
                
                # Get door corners with scaled coordinates
                door_coords = find_most_isolated_corner_and_opposite(scaled_bbox, scaled_win_coords)
                door_coords = [coord.tolist() if isinstance(coord, np.ndarray) else coord 
                             for coord in door_coords]
                # door_coords=[[door_coords[1][0],door_coords[0][1]],[door_coords[0][0],door_coords[1][1]]]
                self.report({'INFO'}, f"Door corners after processing: {door_coords}")
                
                # Find closest wall coordinate
                wall_coordinate = find_closest_wall_coord(door_coords,wall_verts)
                self.report({'INFO'}, f"Found wall coordinate: {wall_coordinate}")
                
                if wall_coordinate:
                    # Verify final position before creating
                    self.report({'INFO'}, f"Final placement coordinates: {wall_coordinate}")
                    window_obj = self.load_window_model(wall_coordinate, wall_height)
                    
                    # Report final object location
                    if window_obj:
                        self.report({'INFO'}, 
                            f"Door object location: {window_obj[0].location if isinstance(window_obj, list) else window_obj.location}")
        # Create floor
        self.create_floor(wall_verts)
        return {'FINISHED'}
    
    
    def load_window_model(self, corners, wall_height):
        """Load and place door with hinge at corner1"""
        addon_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        blend_path = os.path.join(addon_dir, "models", "door.blend")
        
        # Load door model
        with bpy.data.libraries.load(blend_path, link=False) as (data_from, data_to):
            data_to.objects = [name for name in data_from.objects if name.startswith("Door")]
        
        door_obj = data_to.objects[0]
        bpy.context.scene.collection.objects.link(door_obj)
        
        # Get corners and calculate midpoint
        corner1, corner2 = np.array(corners[0]), np.array(corners[1])
        midpoint = (corner1 + corner2) / 2
        
        # Calculate direction vector and angle
        direction = corner2 - corner1
        angle = np.arctan2(direction[1], direction[0])
        
        # Calculate width (distance between corners)
        width = np.linalg.norm(direction)
        
        door_height = door_obj.dimensions.z
        half_height = door_height / 2
        # Set scale and rotation
        door_obj.scale = (width, 1, 1)
        door_obj.rotation_euler[2] = angle
        
        # Place at midpoint 
        door_obj.location = (midpoint[0], midpoint[1], half_height)
        
        return door_obj
def detect_wall_orientation(coords, angle_threshold=5):
    """
    Detect primary orientations including diagonals
    Returns simplified wall coordinates maintaining angle
    """
    coords = np.array(coords)
    dx = coords[-1][0] - coords[0][0]
    dy = coords[-1][1] - coords[0][1]
    angle = np.degrees(np.arctan2(dy, dx)) % 360
    
    # Calculate length
    length = np.sqrt(dx**2 + dy**2)
    
    # Check common angles (0°, 45°, 90°, 135°, 180°)
    common_angles = [0, 45, 90, 135, 180]
    for target_angle in common_angles:
        if abs(angle - target_angle) < angle_threshold:
            # Keep angle but clean up the line
            theta = np.radians(target_angle)
            end_x = coords[0][0] + length * np.cos(theta)
            end_y = coords[0][1] + length * np.sin(theta)
            return [(coords[0][0], coords[0][1]), (end_x, end_y)]
    
    # If not a common angle, return endpoints of best-fit line
    return [(coords[0][0], coords[0][1]), (coords[-1][0], coords[-1][1])]

def find_closest_wall_coord(corners, wall_coords):
    if not wall_coords or len(corners) != 2:
        return None

    corner1 = np.array(corners[0])  # Convert to numpy array for easier calculations
    corner2 = np.array(corners[1])

    # Determine the other two corners of the rectangle assuming axis alignment
    corner3 = np.array([corner1[0], corner2[1]])  # Top-left if corner1 is bottom-left
    corner4 = np.array([corner2[0], corner1[1]])  # Bottom-right if corner2 is top-right

    # Calculate midpoints
    midpoint23 = (corner2 + corner3) / 2
    midpoint42 = (corner4 + corner2) / 2

    # Function to find the minimum distance from a given point to the closest wall segment
    
    def distance_to_closest_wall_point(midpoint, wall_coords):
        min_distance = np.inf
        midpoint = np.array(midpoint)  # Convert the midpoint to a NumPy array for vector operations

        # Iterate through each wall's segments
        for wall in wall_coords:
            for point in wall:  # Each point in the segment
                p = np.array(point)  # Convert point to NumPy array
                distance = np.linalg.norm(midpoint - p)  # Calculate Euclidean distance

                # Update the minimum distance if this point is closer
                if distance < min_distance:
                    min_distance = distance

        return min_distance

    # Calculate distances for each midpoint to their nearest wall point
    dist23 = distance_to_closest_wall_point(midpoint23, wall_coords)
    dist42 = distance_to_closest_wall_point(midpoint42, wall_coords)
    print("dist23: ",dist23)
    print("dist42",dist42)

    # Compare distances and return the pair of corners whose midpoint is farther from the wall
    if dist23 > dist42:
        print(corner2,corner3,":      1 triggered")
        return [corner2.tolist(), corner4.tolist()]
    else:
        print(corner1,corner4,":    2 triggered ")
        return [corner2.tolist(), corner3.tolist()]
def snap_to_grid(coords, grid_size=5):
    """
    Snap coordinates to the nearest grid point and remove consecutive duplicates.

    Parameters:
    - coords: List of (x, y) tuples.
    - grid_size: Size of the grid.

    Returns:
    - List of snapped (x, y) tuples without consecutive duplicates.
    """
    snapped = []
    last_snapped = None
    for x, y in coords:
        gx = round(x / grid_size) * grid_size
        gy = round(y / grid_size) * grid_size
        snapped_point = (gx, gy)
        if snapped_point != last_snapped:
            snapped.append(snapped_point)
            last_snapped = snapped_point
    return snapped
def find_most_isolated_corner_and_opposite(bbox, mask_coords):
    [x1, y1, x2, y2] = bbox
    bbox_corners = np.array([
        [x1, y1],  # top-left
        [x2, y1],  # top-right
        [x2, y2],  # bottom-right
        [x1, y2]   # bottom-left
    ])

    # Track the maximum of minimum distances
    max_min_distance = 0
    most_isolated_corner_index = -1

    # Iterate through each corner to find the minimum distance to the mask points
    for i, corner in enumerate(bbox_corners):
        min_distance = np.min(np.sqrt((mask_coords[:, 0] - corner[0]) ** 2 + (mask_coords[:, 1] - corner[1]) ** 2))
        # Check if this minimum distance is the greatest found so far
        if min_distance > max_min_distance:
            max_min_distance = min_distance
            most_isolated_corner_index = i

    if most_isolated_corner_index == -1:
        return None, None  # In case no corner is sufficiently isolated

    # Calculate the index for the next corner clockwise
    next_corner_index = (most_isolated_corner_index) % 4
    # Calculate the index for the opposite corner to the next corner
    opposite_of_next_index = (next_corner_index + 2) % 4

    # Return the next corner and the opposite corner to the next corner
    return [bbox_corners[next_corner_index], bbox_corners[opposite_of_next_index]]
def simplify_wall_contour(coords, angle_threshold=30, distance_threshold=0.1):
    """
    Simplify wall contour based on angle and distance thresholds.
    Angle threshold is in degrees; distance threshold is in the same units as coords.
    """
    if len(coords) < 3 or (angle_threshold == 0 and distance_threshold == 0):
        return coords

    simplified = [coords[0]]
    last_kept_point = np.array(coords[0])

    for i in range(1, len(coords) - 1):
        current_point = np.array(coords[i])
        next_point = np.array(coords[i + 1])
        prev_point = np.array(simplified[-1])

        # Calculate vectors
        vec_prev = current_point - prev_point
        vec_next = next_point - current_point

        # Calculate angle between vectors
        angle = np.degrees(np.arccos(
            np.clip(np.dot(vec_prev, vec_next) / (np.linalg.norm(vec_prev) * np.linalg.norm(vec_next) + 1e-8), -1.0, 1.0)
        ))

        # Calculate distance
        dist = np.linalg.norm(current_point - last_kept_point)

        # Decide whether to keep the point
        if angle >= angle_threshold or dist >= distance_threshold:
            simplified.append(coords[i])
            last_kept_point = current_point

    simplified.append(coords[-1])  # Always include the last point

    return simplified

def update_walls(self, context):
    """Callback for when slider values change"""
    # Get the operator
    
    bpy.ops.object.generate_walls()

def register():
    # Install dependencies when the addon is registered
    py_exec = bpy.app.binary_path_python

    # Ensure pip is installed
    subprocess.call([str(py_exec), "-m", "ensurepip", "--user"])
    subprocess.call([str(py_exec), "-m", "pip", "install", "--upgrade", "pip", "--user"])

    # Install required packages
    packages = ['ultralytics', 'shapely', 'numpy']
    for package in packages:
        try:
            subprocess.call([str(py_exec), "-m", "pip", "install", "--user", package])
        except Exception as e:
            print(f"Error installing package {package}: {e}")

    # Update sys.path
    import site
    site_packages = site.getusersitepackages()
    if site_packages not in sys.path:
        sys.path.append(site_packages)

    bpy.types.Scene.floor_plan_path = bpy.props.StringProperty(
        name="Floor Plan",
        description="Path to floor plan image",
        subtype='FILE_PATH'
    )
    bpy.types.Scene.wall_height = bpy.props.FloatProperty(
        name="Wall Height",
        description="Height of the walls in meters",
        default=2.4,
        min=0.0,
        unit='LENGTH'
    )
    bpy.types.Scene.angle_threshold = bpy.props.FloatProperty(
        name="Angle Threshold",
        description="Angle threshold for wall simplification (degrees)",
        default=30.0,
        min=0.0,
        max=180.0,
        update=update_walls
    )
    bpy.types.Scene.distance_threshold = bpy.props.FloatProperty(
        name="Distance Threshold",
        description="Distance threshold for wall simplification",
        default=0.1,
        min=0.0,
        max=1.0,
        update=update_walls
    )
    bpy.utils.register_class(WallGeneratorPanel)
    bpy.utils.register_class(WallGeneratorOperator)

def unregister():
    del bpy.types.Scene.floor_plan_path
    del bpy.types.Scene.wall_height
    del bpy.types.Scene.angle_threshold
    del bpy.types.Scene.distance_threshold
    bpy.utils.unregister_class(WallGeneratorPanel)
    bpy.utils.unregister_class(WallGeneratorOperator)

if __name__ == "__main__":
    register()