from .wall_generator import (
    WallGeneratorOperator,
    WallGeneratorPanel,
    update_walls
)

def register():
    from bpy.utils import register_class
    register_class(WallGeneratorPanel)
    register_class(WallGeneratorOperator)

def unregister():
    from bpy.utils import unregister_class
    unregister_class(WallGeneratorPanel) 
    unregister_class(WallGeneratorOperator)

__all__ = [
    'WallGeneratorOperator',
    'WallGeneratorPanel',
    'update_walls'
]
