bl_info = {
    "name": "Wall Generator",
    "author": "Your Name",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Wall Generator",
    "description": "Generate walls from floor plan images using AI",
    "category": "Object",
}

import bpy
from . import operators
import os
import sys
import subprocess

# Get addon directory
addon_dir = os.path.dirname(os.path.realpath(__file__))

def register():
    bpy.types.Scene.floor_plan_path = bpy.props.StringProperty(
        name="Floor Plan",
        description="Path to floor plan image",
        subtype='FILE_PATH'
    )
    bpy.types.Scene.wall_height = bpy.props.FloatProperty(
        name="Wall Height",
        description="Height of the walls in meters",
        default=2.4,
        min=0.0,
        unit='LENGTH'
    )
    bpy.types.Scene.angle_threshold = bpy.props.FloatProperty(
        name="Angle Threshold",
        description="Angle threshold for wall simplification (degrees)",
        default=10.0,
        min=0.0,
        max=180.0,
        update=operators.update_walls
    )
    bpy.types.Scene.distance_threshold = bpy.props.FloatProperty(
        name="Distance Threshold",
        description="Distance threshold for wall simplification",
        default=0.05,
        min=0.0,
        max=1.0,
        step=0.01,
        precision=3,
        update=operators.update_walls
    )
    operators.register()

def unregister():
    del bpy.types.Scene.floor_plan_path
    del bpy.types.Scene.wall_height
    del bpy.types.Scene.angle_threshold
    del bpy.types.Scene.distance_threshold
    operators.unregister()

if __name__ == "__main__":
    register()