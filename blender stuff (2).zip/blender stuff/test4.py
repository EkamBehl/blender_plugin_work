import cv2
import numpy as np
from ultralytics import YOLO
import cv2.ximgproc
from itertools import combinations

def sharpen_mask(mask):
    """Enhance wall edges and corners"""
    # Adaptive thresholding
    mask = cv2.adaptiveThreshold(mask, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                               cv2.THRESH_BINARY, 11, 2)
    
    # Sharpening kernel
    kernel = np.array([[-1,-1,-1], 
                      [-1, 9,-1],
                      [-1,-1,-1]])
    return cv2.filter2D(mask, -1, kernel)

def process_wall_mask(mask, target_shape):
    """Precision processing for architectural walls"""
    # Convert to uint8 and resize
    mask = (mask * 255).astype(np.uint8)
    mask = cv2.resize(mask, target_shape, interpolation=cv2.INTER_NEAREST)
    
    # Edge-preserving morphological operations
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)  # Close small gaps
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)   # Remove debris
    
    # Sharpening step for crisp walls
    mask = sharpen_mask(mask)
    
    # Precision skeletonization
    skeleton = cv2.ximgproc.thinning(mask, thinningType=cv2.ximgproc.THINNING_GUOHALL)
    
    # Clean skeleton
    skeleton = cv2.medianBlur(skeleton, 3)
    
    return mask, skeleton

def find_wall_contours(skeleton):
    """Find precise wall contours with corner preservation"""
    # Enhanced contour detection
    contours, _ = cv2.findContours(skeleton, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    
    # Filter and simplify contours
    clean_contours = []
    min_length = 50  # Minimum wall segment length
    
    for cnt in contours:
        # Approximate contour while preserving corners
        epsilon = 0.001 * cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, epsilon, True)
        
        if cv2.arcLength(approx, False) > min_length:
            clean_contours.append(approx)
            
    return clean_contours

def detect_arch_junctions(contours, skeleton):
    """Architectural junction detection with vector analysis"""
    junctions = {'T': [], 'L': [], 'E': []}
    
    # Create direction vectors for common wall angles
    directions = [(1,0), (0,1), (-1,0), (0,-1),  # Cardinal
                  (1,1), (-1,1), (1,-1), (-1,-1)] # Diagonal
    
    # Analyze each contour point
    for cnt in contours:
        for i, point in enumerate(cnt):
            x, y = point[0]
            
            # Skip edge regions
            if x < 10 or y < 10 or x > skeleton.shape[1]-10 or y > skeleton.shape[0]-10:
                continue
                
            # Check 7x7 neighborhood for better context
            roi = skeleton[y-3:y+4, x-3:x+4]
            
            # Count orthogonal connections
            connections = 0
            vectors = []
            for dy in range(-3, 4):
                for dx in range(-3, 4):
                    if roi[3+dy, 3+dx] == 255:
                        dist = np.sqrt(dx**2 + dy**2)
                        if 2 < dist < 4:  # Look for meaningful connections
                            vectors.append((dx, dy))
                            connections += 1
            
            # Classify based on connection pattern
            if connections == 3:
                junctions['T'].append((x,y))
            elif connections == 2:
                # Vector angle analysis
                v1, v2 = vectors
                dot = v1[0]*v2[0] + v1[1]*v2[1]
                det = v1[0]*v2[1] - v1[1]*v2[0]
                angle = np.abs(np.degrees(np.arctan2(det, dot)))
                
                if 85 < angle < 95:  # Right angle
                    junctions['L'].append((x,y))
            elif connections == 1:
                junctions['E'].append((x,y))
    
    return junctions

def visualize_results(original, mask, skeleton, junctions):
    """Architectural visualization with measurements"""
    viz = original.copy()
    
    # Draw skeleton in white
    viz[skeleton == 255] = (255, 255, 255)
    
    # Draw junctions
    for j_type, color in [('T', (0,255,0)), ('L', (255,0,0)), ('E', (0,0,255))]:
        for x, y in junctions[j_type]:
            cv2.drawMarker(viz, (x,y), color, cv2.MARKER_CROSS, 20, 2)
    
    # Create measurement overlay
    h, w = viz.shape[:2]
    overlay = np.zeros((h, w//3, 3), dtype=np.uint8)
    
    # Add counts
    texts = [
        f"T-Junctions: {len(junctions['T'])}",
        f"L-Junctions: {len(junctions['L'])}",
        f"Endpoints: {len(junctions['E'])}"
    ]
    
    for i, text in enumerate(texts):
        cv2.putText(overlay, text, (10, 30*(i+1)), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
    
    return np.hstack([viz, overlay])

def main():
    img = cv2.imread('z.jpg')
    model = YOLO('my_wall_generator/weights/best2.pt')
    results = model.predict(img)
    result = results[0]

    if result.masks is not None:
        masks = result.masks.data.cpu().numpy()
        names = result.names

        for i, mask in enumerate(masks):
            class_id = int(result.boxes.cls[i])
            if names[class_id].lower() == "wwaall":
                # Process wall mask
                binary_mask, skeleton = process_wall_mask(mask, img.shape[:2][::-1])
                
                # Find precise contours
                contours = find_wall_contours(skeleton)
                
                # Detect architectural junctions
                junctions = detect_arch_junctions(contours, skeleton)
                
                # Visualize results
                result_viz = visualize_results(img, binary_mask, skeleton, junctions)
                
                # Show comparison
                cv2.imshow('Architectural Analysis', result_viz)
                print(f"T: {len(junctions['T'])}, L: {len(junctions['L'])}, E: {len(junctions['E'])}")
                cv2.waitKey(0)
                
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()