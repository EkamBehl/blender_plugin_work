import json
import numpy as np
import os
from shapely.geometry import Polygon

def load_json_data(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
        
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
            if not data:
                raise ValueError("Empty JSON data")
            return data
    except json.JSONDecodeError as e:
        print(f"Invalid JSON format: {e}")
        return []

def check_area_overlap(coords1, coords2):
    """Calculate overlapping area between two walls"""
    try:
        # Create polygons from coordinates
        poly1 = Polygon(coords1)
        poly2 = Polygon(coords2)
        
        if not poly1.is_valid or not poly2.is_valid:
            return 0
            
        intersection = poly1.intersection(poly2)
        return intersection.area
        
    except Exception as e:
        print(f"Error calculating overlap: {e}")
        return 0

def find_overlapping_areas(data):
    """Find all overlapping areas between walls"""
    walls = [item for item in data if item['class'] == 'wall']
    overlaps = []
    
    for i in range(len(walls)):
        for j in range(i + 1, len(walls)):
            area = check_area_overlap(walls[i]['coords'], walls[j]['coords'])
            if area > 0:
                overlaps.append({
                    'wall1': i,
                    'wall2': j,
                    'area': area,
                    'coords1': walls[i]['coords'],
                    'coords2': walls[j]['coords']
                })
    return overlaps

if __name__ == "__main__":
    data = load_json_data('sample_data.json')
    overlaps = find_overlapping_areas(data)
    
    if overlaps:
        print("\nOverlapping walls found:")
        for overlap in overlaps:
            print(f"\nWalls {overlap['wall1']} and {overlap['wall2']}")
            print(f"Overlap area: {overlap['area']:.2f}")
    else:
        print("No overlapping walls found")