import cv2
import numpy as np
from ultralytics import YOLO
import cv2.ximgproc
from itertools import combinations

def debug_show(name, image, wait=True):
    """Enhanced visualization with metadata"""
    print(f"[DEBUG] {name}: shape={image.shape}, dtype={image.dtype}, min={np.min(image)}, max={np.max(image)}")
    if image.dtype == np.bool_ or image.dtype == bool:
        image = image.astype(np.uint8) * 255
    if len(image.shape) == 2:
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    cv2.imshow(name, image)
    if wait:
        cv2.waitKey(0)
        cv2.destroyWindow(name)

def prune_skeleton(skeleton, prune_threshold=5):
    """Less aggressive pruning for debugging"""
    pruned = np.copy(skeleton)
    
    # Find endpoints using convolution
    kernel = np.array([[1, 1, 1],
                       [1, 10, 1],
                       [1, 1, 1]], dtype=np.uint8)
    conv = cv2.filter2D(pruned//255, -1, kernel)
    endpoints = np.argwhere(conv == 11)  # Points with exactly 1 neighbor
    
    for y, x in endpoints:
        branch = []
        queue = [(x, y)]
        visited = set()
        
        while queue:
            cx, cy = queue.pop(0)
            if (cx, cy) in visited:
                continue
            visited.add((cx, cy))
            branch.append((cx, cy))
            
            # Find neighbors
            neighbors = []
            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    if dx == 0 and dy == 0:
                        continue
                    nx, ny = cx + dx, cy + dy
                    if 0 <= nx < pruned.shape[1] and 0 <= ny < pruned.shape[0]:
                        if pruned[ny, nx] == 255 and (nx, ny) not in visited:
                            neighbors.append((nx, ny))
            
            queue.extend(neighbors)
            
            # Stop if we reach a junction
            if len(neighbors) > 1:
                break
        
        # Only prune very short branches
        if len(branch) <= prune_threshold:
            for cx, cy in branch:
                pruned[cy, cx] = 0
                
    return pruned

def process_mask(mask, shape):
    """More transparent mask processing with debug"""
    # Convert YOLO mask to binary
    mask = (mask > 0.5).astype(np.uint8) * 255  # Explicit thresholding
    debug_show("0. Raw YOLO Mask", mask)
    
    mask = cv2.resize(mask, shape, interpolation=cv2.INTER_NEAREST)
    debug_show("1. Resized Mask", mask)
    
    # Gentle cleaning
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3,3))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
    debug_show("2. After Closing", mask)
    
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    debug_show("3. After Opening", mask)
    
    # Skeletonization with different method
    skeleton = cv2.ximgproc.thinning(mask, thinningType=cv2.ximgproc.THINNING_GUOHALL)
    debug_show("4. Initial Skeleton", skeleton)
    
    # Light pruning
    skeleton = prune_skeleton(skeleton)
    debug_show("5. Pruned Skeleton", skeleton)
    
    # Contour detection with different mode
    contours, _ = cv2.findContours(skeleton, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    
    # Draw contours for debug
    contour_viz = cv2.cvtColor(skeleton, cv2.COLOR_GRAY2BGR)
    cv2.drawContours(contour_viz, contours, -1, (0,255,0), 1)
    debug_show("6. Contours on Skeleton", contour_viz)
    
    return mask, skeleton, contours

def find_junctions(contours, skeleton):
    """More lenient junction detection"""
    t_junctions = []
    l_junctions = []
    endpoints = []
    
    # Create distance transform
    dt = cv2.distanceTransform(255 - skeleton, cv2.DIST_L2, 3)
    
    for contour in contours:
        for i in range(len(contour)):
            x, y = contour[i][0]
            
            # Check boundary conditions
            if x < 2 or y < 2 or x >= skeleton.shape[1]-2 or y >= skeleton.shape[0]-2:
                continue
                
            # Analyze neighborhood
            neighborhood = dt[y-2:y+3, x-2:x+3].copy()
            neighborhood[2, 2] = 0  # Ignore center
            
            branches = []
            for dy in [-2, 0, 2]:
                for dx in [-2, 0, 2]:
                    if dx == 0 and dy == 0:
                        continue
                    if neighborhood[2+dy, 2+dx] > 0.8:  # Lower threshold
                        branches.append((dx, dy))
            
            # Classification with wider angles
            if len(branches) == 3:
                t_junctions.append((x, y))
            elif len(branches) == 2:
                vec1 = np.array(branches[0])
                vec2 = np.array(branches[1])
                dot = np.dot(vec1, vec2)
                det = vec1[0]*vec2[1] - vec1[1]*vec2[0]
                angle = np.abs(np.degrees(np.arctan2(det, dot)))
                if 60 < angle < 120:
                    l_junctions.append((x, y))
            elif len(branches) == 1:
                endpoints.append((x, y))
    
    print(f"Pre-merge counts - T: {len(t_junctions)}, L: {len(l_junctions)}, E: {len(endpoints)}")
    return t_junctions, l_junctions, endpoints

def main():
    img = cv2.imread('z.jpg')
    model = YOLO('my_wall_generator/weights/best2.pt')
    results = model.predict(img)
    result = results[0]

    if result.masks is not None:
        masks = result.masks.data.cpu().numpy()
        names = result.names

        for i, mask in enumerate(masks):
            class_id = int(result.boxes.cls[i])
            if names[class_id].lower() == "wwaall":
                print("\n" + "="*40)
                print(f"Processing mask {i+1}/{len(masks)}")
                
                # Process mask with debug
                binary_mask, skeleton, contours = process_mask(mask, (img.shape[1], img.shape[0]))
                
                # Verify contours
                print(f"Number of contours: {len(contours)}")
                if len(contours) == 0:
                    print("No contours found! Check skeletonization.")
                    continue
                
                # Find junctions
                t_junc, l_junc, endp = find_junctions(contours, skeleton)
                
                # Visualization
                viz = cv2.cvtColor(skeleton, cv2.COLOR_GRAY2BGR)
                for x, y in t_junc:
                    cv2.drawMarker(viz, (x,y), (0,255,0), cv2.MARKER_CROSS, 20, 2)
                for x, y in l_junc:
                    cv2.drawMarker(viz, (x,y), (255,0,0), cv2.MARKER_CROSS, 20, 2)
                for x, y in endp:
                    cv2.drawMarker(viz, (x,y), (0,0,255), cv2.MARKER_CROSS, 20, 2)
                
                debug_show("Final Result", viz, wait=False)
                print(f"Detected: T={len(t_junc)}, L={len(l_junc)}, E={len(endp)}")
                
                # Compare with original
                combined = np.hstack([
                    cv2.resize(cv2.cvtColor(binary_mask, cv2.COLOR_GRAY2BGR), (viz.shape[1], viz.shape[0])),
                    viz
                ])
                debug_show("Mask vs Result", combined)
                
                cv2.destroyAllWindows()

if __name__ == '__main__':
    main()