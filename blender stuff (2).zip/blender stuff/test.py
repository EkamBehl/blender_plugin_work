import cv2
import numpy as np
from ultralytics import YOLO
from scipy.spatial import KDTree

def process_mask(mask, target_shape):
    """Process YOLO mask to clean binary format"""
    mask = (mask > 0.5).astype(np.uint8) * 255
    mask = cv2.resize(mask, target_shape, interpolation=cv2.INTER_NEAREST)
    
    # Clean with morphological operations
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    
    return cv2.ximgproc.thinning(mask)

def vectorize_contours(skeleton, angle_threshold=5):
    """Convert skeleton to vectorized straight-line contours"""
    contours, _ = cv2.findContours(skeleton, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    
    vectorized = []
    for cnt in contours:
        # Initial approximation
        epsilon = 0.02 * cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, epsilon, True)
        
        # Angle-based simplification
        simplified = []
        for i in range(len(approx)):
            p1 = approx[i-1][0]
            p2 = approx[i][0]
            p3 = approx[(i+1)%len(approx)][0]
            
            vec1 = p2 - p1
            vec2 = p3 - p2
            angle = np.degrees(np.arctan2(np.cross(vec1, vec2), np.dot(vec1, vec2)))
            
            if abs(angle) > angle_threshold:
                simplified.append(p2)
        
        # Final constrained approximation
        epsilon = 0.01 * cv2.arcLength(cnt, True)
        vectorized.append(cv2.approxPolyDP(
            np.array(simplified), epsilon, True
        ))
    
    return vectorized

def detect_arch_junctions(contours, snap_distance=5, angle_increment=45):
    """Detect architectural junctions with angle snapping"""
    all_points = np.vstack([c.reshape(-1,2) for c in contours])
    kd_tree = KDTree(all_points)
    
    junctions = {'T': [], 'L': [], 'cross': []}
    
    for idx, pt in enumerate(all_points):
        # Find nearby points
        neighbors = kd_tree.query_ball_point(pt, snap_distance)
        if len(neighbors) < 3:
            continue
        
        # Get vectors to neighbors
        vectors = []
        for n_idx in neighbors:
            if n_idx == idx:
                continue
            dx = all_points[n_idx][0] - pt[0]
            dy = all_points[n_idx][1] - pt[1]
            vectors.append((dx, dy))
        
        # Snap angles to nearest increment
        snapped_angles = []
        for dx, dy in vectors:
            angle = np.degrees(np.arctan2(dy, dx))
            snapped = angle_increment * round(angle/angle_increment)
            snapped_angles.append(snapped)
        
        # Count unique directions
        unique_dirs = len(set(snapped_angles))
        
        # Classify junctions
        if unique_dirs >= 4:
            junctions['cross'].append(pt)
        elif unique_dirs == 3:
            junctions['T'].append(pt)
        elif unique_dirs == 2:
            angle_diff = abs(snapped_angles[0] - snapped_angles[1])
            if 80 < angle_diff % 180 < 100:
                junctions['L'].append(pt)
    
    return junctions

def visualize_results(image, contours, junctions):
    """Visualize vectorized walls and junctions"""
    viz = image.copy()
    
    # Draw vectorized walls
    cv2.drawContours(viz, contours, -1, (0,255,255), 2)
    
    # Draw junctions
    colors = {'T': (0,255,0), 'L': (255,0,0), 'cross': (0,0,255)}
    for j_type, pts in junctions.items():
        for x, y in pts:
            cv2.drawMarker(viz, (int(x), int(y)), colors[j_type], 
                          cv2.MARKER_CROSS, 20, 2)
    
    return viz

def main():
    # Load input and model
    img = cv2.imread('z.jpg')
    model = YOLO('my_wall_generator/weights/best2.pt')  # Your trained model
    
    # Detect walls
    results = model.predict(img)
    wall_mask = results[0].masks.data[0].cpu().numpy()
    
    # Process mask
    skeleton = process_mask(wall_mask, img.shape[:2][::-1])
    
    # Vectorize contours
    vectorized = vectorize_contours(skeleton)
    
    # Detect junctions
    junctions = detect_arch_junctions(vectorized)
    
    # Visualize and save
    result_viz = visualize_results(img, vectorized, junctions)
    cv2.imwrite('analysis_result.jpg', result_viz)
    cv2.imshow('Architectural Analysis', result_viz)
    cv2.waitKey(0)

if __name__ == '__main__':
    main()