bl_info = {
    "name": "Wall Generator",
    "author": "ekamb",
    "version": (3, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Wall Generator",
    "description": "Generate walls from floor plan images using AI",
    "category": "Object",
}

import bpy
import os
import sys
import subprocess
import site
import numpy as np

# Get addon directory
addon_dir = os.path.dirname(os.path.realpath(__file__))

def install_dependencies():
    python_exe = sys.executable
    pip_install = [python_exe, "-m", "pip", "install", "--user"]
    subprocess.check_call(pip_install + ["ultralytics"])
    
class WallGeneratorPanel(bpy.types.Panel):
    bl_label = "Wall Generator"
    bl_idname = "VIEW3D_PT_wall_generator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Wall Generator'

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "floor_plan_path")
        layout.operator("object.generate_walls")

class WallGeneratorOperator(bpy.types.Operator):
    bl_idname = "object.generate_walls"
    bl_label = "Generate Walls"
    
    def execute(self, context):
        try:
            from ultralytics import YOLO
            addon_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
            
            # Load model from addon directory
            model_path = os.path.join(addon_dir, "weights", "best2.pt")
            model = YOLO(model_path)
            
            # Get image path
            image_path = context.scene.floor_plan_path
            if not os.path.exists(image_path):
                self.report({'ERROR'}, f"Image not found: {image_path}")
                return {'CANCELLED'}
                
            results = model.predict(image_path, conf=0.3)
            wall_height = context.scene.wall_height
            
            # Lists to collect vertices for floor creation
            all_wall_verts = []
            all_wall_faces = []
            
            # Process each detected wall separately
            masks = results[0].masks
            boxes = results[0].boxes.cpu().numpy()
            names = results[0].names

            # Iterate over detections
            for i in range(len(boxes)):
                class_idx = int(boxes[i, 5])
                class_name = names[class_idx]
                if class_name == 'wwaall':
                    # Get coordinates for this specific wall
                    wall_coords = masks.data[i].cpu().numpy()
                    if isinstance(wall_coords, np.ndarray):
                        wall_coords = wall_coords.reshape(-1, 2).tolist()
                    
                    # Create vertices for this wall
                    bottom_verts = [(v[0], v[1], 0) for v in wall_coords]
                    top_verts = [(v[0], v[1], wall_height) for v in wall_coords]
                    verts = bottom_verts + top_verts
                    
                    # Collect all bottom vertices for floor creation
                    all_wall_verts.extend(bottom_verts)
                    
                    num_points = len(wall_coords)
                    bottom_face = list(range(num_points))
                    top_face = [i + num_points for i in range(num_points)]
                    
                    # Create side faces
                    side_faces = []
                    for j in range(num_points):
                        next_j = (j + 1) % num_points
                        side_faces.append([j, next_j, next_j + num_points, j + num_points])
                    
                    faces = side_faces + [bottom_face, top_face]
                    
                    # Create mesh for this wall
                    mesh = bpy.data.meshes.new(f'Wall_{i}')
                    mesh.from_pydata(verts, [], faces)
                    mesh.update()
                    
                    # Create object for this wall
                    obj = bpy.data.objects.new(f'Wall_{i}', mesh)
                    bpy.context.scene.collection.objects.link(obj)
                    
                    # Apply material to the wall
                    material = create_wall_material()
                    obj.data.materials.append(material)
            
            # Create floor after walls are generated
            if all_wall_verts:
                create_floor(all_wall_verts)
            
            return {'FINISHED'}
            
        except ImportError:
            install_dependencies()
            self.report({'WARNING'}, "Dependencies installed. Please restart Blender")
            return {'CANCELLED'}

def create_wall_material():
    mat_name = "Default_Wall_Material"
    material = bpy.data.materials.get(mat_name)
    if material is None:
        # Create new material
        material = bpy.data.materials.new(name=mat_name)
        material.use_nodes = True
        
        # Clear default nodes
        nodes = material.node_tree.nodes
        links = material.node_tree.links
        nodes.clear()
        
        # Add nodes
        output_node = nodes.new(type='ShaderNodeOutputMaterial')
        principled_node = nodes.new(type='ShaderNodeBsdfPrincipled')
        
        # Set base color (you can change the color as needed)
        principled_node.inputs['Base Color'].default_value = (0.8, 0.8, 0.8, 1)  # Light gray
        
        # Link nodes
        links.new(principled_node.outputs['BSDF'], output_node.inputs['Surface'])
        
    return material

def create_floor_material():
    mat_name = "Default_Floor_Material"
    material = bpy.data.materials.get(mat_name)
    if material is None:
        # Create new material
        material = bpy.data.materials.new(name=mat_name)
        material.use_nodes = True
        
        # Clear default nodes
        nodes = material.node_tree.nodes
        links = material.node_tree.links
        nodes.clear()
        
        # Add nodes
        output_node = nodes.new(type='ShaderNodeOutputMaterial')
        principled_node = nodes.new(type='ShaderNodeBsdfPrincipled')
        
        # Set base color for floor
        principled_node.inputs['Base Color'].default_value = (0.5, 0.5, 0.5, 1)  # Medium gray
        
        # Link nodes
        links.new(principled_node.outputs['BSDF'], output_node.inputs['Surface'])
        
    return material

def create_floor(all_wall_verts):
    # Calculate bounds of all walls
    min_x = min(v[0] for v in all_wall_verts)
    max_x = max(v[0] for v in all_wall_verts)
    min_y = min(v[1] for v in all_wall_verts)
    max_y = max(v[1] for v in all_wall_verts)
    
    # Create floor vertices
    floor_verts = [
        (min_x, min_y, 0),  # Bottom left
        (max_x, min_y, 0),  # Bottom right
        (max_x, max_y, 0),  # Top right
        (min_x, max_y, 0),  # Top left
    ]
    
    # Create floor face
    floor_faces = [(0, 1, 2, 3)]
    
    # Create floor mesh
    floor_mesh = bpy.data.meshes.new('Floor')
    floor_mesh.from_pydata(floor_verts, [], floor_faces)
    floor_mesh.update()
    
    # Create floor object
    floor_obj = bpy.data.objects.new('Floor', floor_mesh)
    bpy.context.scene.collection.objects.link(floor_obj)
    
    # Apply material to the floor
    floor_material = create_floor_material()
    floor_obj.data.materials.append(floor_material)

def register():
    bpy.types.Scene.floor_plan_path = bpy.props.StringProperty(
        name="Floor Plan",
        description="Path to floor plan image",
        subtype='FILE_PATH'
    )
    bpy.utils.register_class(WallGeneratorPanel)
    bpy.utils.register_class(WallGeneratorOperator)

def unregister():
    del bpy.types.Scene.floor_plan_path
    bpy.utils.unregister_class(WallGeneratorPanel)
    bpy.utils.unregister_class(WallGeneratorOperator)

if __name__ == "__main__":
    register()